import React from 'react'

const jobs = () => {
  return (
    <div>jobs</div>
  )
}

export default jobs